MIM Usage
=========
Description
-----------

This is a man-in-the-middle proxy server and related utilities. The core proxy passes requests to their destination; and passes the response back to the client unchanged. It also shows a log of requests and responses; and fires signals.

Plugins that subscribe to the signals can read and manipulate requests and responses. A number of example plugins are included. It is very easy to add more using the examples as a template.

Installation
------------

* download mim-9.9.9.tar.gz from pypi or https://github.com/simonm3/mim/dist
* tar -zxvf mim-9.9.9.tar.gz
* workon <virtualenv>
* pip install -r requirements.txt
* if you want to use the beef framework then: apt-get install beef-xss
* if you want to use fakeAP: download from https://github.com/DanMcInerney/fakeAP

OR git clone from https://github.com/simonm3/mim

pip install does not work properly e.g. arp.py requires su login and path to be set


Scripts (run with -h to see usage and options)
----------------------------------------------

============== ====================================
script			description
============== ====================================
proxy.py      	 start the proxyserver with plugins
proxy1(bash)	run proxy with default options -ks
users.py		list users on the network so you can select a target
arp.py		arp poison
fakeAP.py	create fake access point

============== ====================================

Plugin options for proxy.py
---------------------------

============== ==================================================
option			description
============== ==================================================
--auth		Log userids/passwords
--beef            Inject beef hook (browser exploitation framework)
--cats            Replace images with cats
--favicon         Replace favicon with lock symbol
--inject          Inject data/injection.html
--kill            Kill session on first visit to domain (forces relogin)
--requests        Log requests
--sslstrip        Replace https with http then proxy links via https
--upsidedown      Turn images upsidedown

============== ==================================================

How to send requests to the proxy
---------------------------------

There are a number of alternative ways of directing traffic to the proxy server:

i. Redirect browser

* Set browser proxy settings to point to ip address of proxy PC port 10000
* /proxy.py

ii. Run arp attack

* ./proxy.py [NOTE: run first else target will have loss of service]
* ./users.py to see available machines to target on the local network
* sudo ./arp.py -t <ip address> to initiate arp attack on a target ip

iii. Run fake access point
	
* sudo ./fakeAP.py
* connect to Free Wifi from target pc
* ./proxy.py [NOTE: run after fakeAP to set firewall settings]

How to create a plugin
----------------------

To create a plugin called "test":

* Create a module file "plugins/test.py" based on other modules in plugins folder.
* Use decorators e.g. @on(gotRequest) to link functions to the signals fired by the proxy. The signals are gotRequest, gotResponseTree, gotResponseText, gotResponseImage.
* Edit the docstring for proxy.py to add the option

To add a plugin to "otherplugins" (a single file containing many smaller plugins):

* Follow the same format as the other plugins in "plugins/otherplugins"
* Edit the docstring for proxy.py to add the option

Where does it work
------------------

* Tested via usage on a range of websites using proxy settings, arp attack and fakeAP
* It should never block and has a timeout on web requests

Where does it not work
----------------------

* Some security software prevents arp attacks
* Https requests typed directly in the address bar will not be intercepted
* HttpsEverywhere (chrome extension) prevents interception
* Some websites enforce https via the browser e.g. gmail, facebook
* Some websites change http links back to https after the page loads e.g. ebay
* Some websites have misformed html. Calling lxml.html.fromstring then tostring can change the appearance of the page as the parser attempts to correct problems. An alternative is to use lxml.etree instead but this causes issues with other pages and is missing functions such as rewrite_links.

-----

MIM Design
==========

Core files
----------

Built in python2.7 using "twisted.web" and follows this chain:

* proxy1 (a bash script that runs proxy.py with selected options)

   => Proxy.py

* proxyserver [listens for connections]

   => ProxyFactory(http.HTTPFactory)

   => Proxy(http.HTTPChannel)

   => Request(http.Request)

* proxyclient [creates connections to web]

   => ProxyClientFactory(proxy.ProxyClientFactory)

   => ProxyClient(proxy.ProxyClient, TimeoutMixin)

   => internet

Uses pydispatch2 (extended pydispatch) to manage signals

* proxyclient and proxyserver send signals
* plugins listen for signals

Other files
-----------

==================== ======================================
file			description
==================== ======================================
tools.fileserver.py	simple file server e.g. to serve images
tools.bash.py		wrapper for bash commands
tools.pydispatch2.py	decorator that connects a function to a signal
tools.logs.py		configuration for tools.logs
log.txt			log of current session. This is cleared on each run.

==================== ======================================

