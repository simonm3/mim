version = "1.0.0"
author = 'simon'
author_email = 'simonm3@gmail.com'
github_user = 'simoneva'